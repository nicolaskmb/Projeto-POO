package com.gameStash.service;

import com.gameStash.model.Relatorio;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

@Service
public class RelatorioService {

    public Relatorio relatorioDeBarra() {
        var dto = new Relatorio();
        dto.setTitulo("Precipitação Média em Joinville");
        dto.setLegenda("Total por dia");
        dto.setXLabel("Mês");
        var valores = new ArrayList<String>();
        var labels = new ArrayList<String>();
        labels.add("Jan");
        labels.add("Feb");
        labels.add("Mar");
        labels.add("Apr");
        labels.add("May");
        labels.add("Jun");
        labels.add("Jul");
        labels.add("Aug");
        labels.add("Sep");
        labels.add("Oct");
        labels.add("Nov");
        labels.add("Dec");

        valores.add("266.6");
        valores.add("188");
        valores.add("178.2");
        valores.add("98.3");
        valores.add("99.9");
        valores.add("90.6");
        valores.add("90.1");
        valores.add("112.7");
        valores.add("140.1");
        valores.add("162.4");
        valores.add("146.9");
        valores.add("172.6");

        dto.setLabels(labels);
        dto.setValores(valores);
        return dto;
    }
}

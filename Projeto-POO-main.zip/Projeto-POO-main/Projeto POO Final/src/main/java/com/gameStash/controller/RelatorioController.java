package com.gameStash.controller;

import com.gameStash.model.Relatorio;
import com.gameStash.service.RelatorioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/graph")
public class RelatorioController {

    @Autowired
    private RelatorioService relatorioService;


    @GetMapping("/bar")
    public ModelAndView barra(){
        var mv = new ModelAndView("relatorio/barra");
        Relatorio relatorioDTO = relatorioService.relatorioDeBarra();
        mv.addObject("relatorio", relatorioDTO);
        return mv;
    }
}

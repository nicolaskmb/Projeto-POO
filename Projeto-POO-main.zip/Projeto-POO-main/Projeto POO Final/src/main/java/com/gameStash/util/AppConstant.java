package com.gameStash.util;

public class AppConstant {

	public static final long UNLOCK_DURATION_TIME = 30;

	public static final long ATTEMPT_TIME = 3;
}

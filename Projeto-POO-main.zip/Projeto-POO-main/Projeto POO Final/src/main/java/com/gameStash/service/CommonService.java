package com.gameStash.service;

public interface CommonService {

	public void removeSessionMessage();

}

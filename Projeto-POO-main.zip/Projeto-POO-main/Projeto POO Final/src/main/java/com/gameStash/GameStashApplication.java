package com.gameStash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameStashApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameStashApplication.class, args);
	}

}

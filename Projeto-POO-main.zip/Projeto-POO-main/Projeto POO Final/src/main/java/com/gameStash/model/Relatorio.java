package com.gameStash.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class Relatorio {
    private String titulo;
    private String legenda;
    private String xLabel;
    private String yLabel;
    private List<String> labels;
    private List<String> valores;
    private List<String> cores;
}
